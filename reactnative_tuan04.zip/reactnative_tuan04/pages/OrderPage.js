import { Text, SafeAreaView, StyleSheet, Image, View,TouchableOpacity, Linking } from 'react-native';
import {useState} from 'react'
// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack

export default function OrderPage(){
  const [price, setPrice]= useState(141800)
  const [unit,setUnit]= useState(1)
  const unitPrice= 141800
  const increaseUnit = () => {
  setUnit(prev => {
    const newUnit = prev + 1;
    setPrice(newUnit * unitPrice);
    return newUnit;
  });
};

const decreaseUnit = () => {
  setUnit(prev => {
    if (prev > 1) {
      const newUnit = prev - 1;
      setPrice(newUnit * unitPrice);
      return newUnit;
    }
    return prev;
  });
};
const changeTotalPrice=()=>{
  setPrice(unit*unitPrice)
}

  return(
    <SafeAreaView style={styles.container}>
      <View style={{height: 280, gap: 20, backgroundColor: "#fff"}}>
        <View style={{ flexDirection: "row", gap: 20}}>
            <View>
            <Image source={require('../assets/book.png') }  style={{width: 104, height: 150}}></Image>
            </View>
            <View style={{flexDirection: "column", gap: 10}}>
              <Text style={{fontWeight:"bold", fontSize: 15}}>Nguyen ham tich phan va ung dung</Text>
              <Text style={{fontWeight:"bold", fontSize: 13}}>Cung cap boi tiki trading</Text>
              <Text style={{fontWeight:"bold", fontSize: 13, color: "red"}}>{unitPrice.toLocaleString('vi-VN')} d</Text>
              <Text style={{fontWeight:"bold", fontSize: 13, color: "gray", textDecorationLine: 'line-through'}}>{unitPrice.toLocaleString('vi-VN')} d</Text>
              <View style={{flexDirection:"row", gap: 20}}>
              
              
              <TouchableOpacity style={styles.button} onPress={decreaseUnit}>-</TouchableOpacity>
              <Text>{unit}</Text>
              <TouchableOpacity style={styles.button} onPress={increaseUnit}>+</TouchableOpacity>
              <TouchableOpacity style={{color: "blue", fontWeight:"bold"}}>Mua tai day</TouchableOpacity>
            </View>
            </View>
            
        </View>
        <View style={{gap: 20}}>
          <View style={{flexDirection:"row", gap: 20}}> 
            <Text>Ma giam gia da luu</Text>
            <Text style={{fontWeight:"bold", color:"blue"}}>Xem tai day</Text>
          </View>
          <View style={{flexDirection: "row", gap: 30}}>
            <TouchableOpacity style={{padding: 5, borderRadius: 5, borderColor: "#ccc", borderWidth: 1, paddingHorizontal: 100}}>Ma giam gia</TouchableOpacity>
            <TouchableOpacity style={{backgroundColor: "blue", fontWeight: "bold", color: "#fff", justifyContent: "center", alignItems:"center", padding: 10}} onPress={increaseUnit}>Ap dung</TouchableOpacity>
          </View>
        </View>
        
      </View>
      <View style={{ flex: 2, justifyContent: "flex-start", gap: 50 }}>

        <View style={{backgroundColor: "#fff", flexDirection: "row", gap: 10, height:30, alignItems: "center"}}>
          <Text>Ban co phieu qua tang Tiki/Got it/ Urbox?</Text>
          <TouchableOpacity style={{color: "blue", fontWeight: "bold"}}>Nhap tai day</TouchableOpacity>
        </View>

<View style={{backgroundColor: "#fff", flexDirection: "row", gap: 10, justifyContent: "space-between", height:30}}>
        <Text style={{fontSize:20, fontWeight: "bold"}}>Tam tinh</Text>
        <Text style={{fontSize:20, fontWeight: "bold",color: "red"}}>{price.toLocaleString("vn-VN")}d</Text>

        
        </View>
      </View>
      
      <View style={{flex: 1, backgroundColor: "#fff", gap:10, padding:5}}
      >
      <View style={{flexDirection:"row", justifyContent:"space-between"}}><Text style={{color:"gray", fontWeight: "bold", fontSize:25}}>Thanh tien </Text> 
        <Text style={{fontSize:20, fontWeight: "bold",color: "red"}}>{price.toLocaleString("vn-VN")}d</Text>
      </View>
      <TouchableOpacity style={{backgroundColor:"red", padding:10, alignItems:"center",justifyContent:"center", fontSize:15, fontWeight:"bold", color:"#fff"}}>Tien hanh dat hang</TouchableOpacity>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'gray',
    padding: 8,
    gap: 20
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  button:{
    padding: 5,
    backgroundColor: "#f5f5f5",
    color: "gray"
  }
});