import React, { useState } from "react";
import { View, Text, TextInput, Button, Switch, StyleSheet, TouchableOpacity, CheckBox } from "react-native";
import * as Clipboard from "expo-clipboard";

const sets = {
  lower: "abcdefghijklmnopqrstuvwxyz",
  upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  number: "0123456789",
  symbol: "!@#$%^&*()-_=+[]{}|;:,.<>?/~`",
};

export default function PassGenerator() {
  const [length, setLength] = useState("12");
  const [includeLower, setIncludeLower] = useState(true);
  const [includeUpper, setIncludeUpper] = useState(false);
  const [includeNumber, setIncludeNumber] = useState(true);
  const [includeSymbol, setIncludeSymbol] = useState(false);
  const [password, setPassword] = useState("");

  const getRandomInt = (max) => {
    return Math.floor(Math.random() * max);
  };

  const generatePassword = () => {
    const len = Math.max(4, Math.min(128, parseInt(length) || 12));
    let pool = "";
    if (includeLower) pool += sets.lower;
    if (includeUpper) pool += sets.upper;
    if (includeNumber) pool += sets.number;
    if (includeSymbol) pool += sets.symbol;

    if (!pool) {
      alert("Vui lòng chọn ít nhất 1 loại ký tự!");
      return;
    }

    let result = "";
    for (let i = 0; i < len; i++) {
      result += pool[getRandomInt(pool.length)];
    }
    setPassword(result);
  };

  const copyToClipboard = async () => {
    if (password) {
      await Clipboard.setStringAsync(password);
      alert("Password copied!");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>PASSWORD GENERATOR</Text>

      <TouchableOpacity onPress={copyToClipboard} style={styles.outputBox}>
        <Text selectable style={styles.passwordText}>
          {password || "Your password will appear here"}
        </Text>
      </TouchableOpacity>

      <View style={styles.row}>
        <Text style={{color:"#fff"}}>Password length:</Text>
        <TextInput
          style={styles.input}
          value={length}
          onChangeText={setLength}
          keyboardType="numeric"
        />
      </View>

      <View style={styles.option}>
  <Text style={{ color: "#fff" }}>Include lower case letters</Text>
  <CheckBox
    value={includeLower}
    onValueChange={setIncludeLower}
    tintColors={{ true: "#4CAF50", false: "#fff" }}
  />
</View>

<View style={styles.option}>
  <Text style={{ color: "#fff" }}>Include upper case letters</Text>
  <CheckBox
    value={includeUpper}
    onValueChange={setIncludeUpper}
    tintColors={{ true: "#4CAF50", false: "#fff" }}
  />
</View>

<View style={styles.option}>
  <Text style={{ color: "#fff" }}>Include numbers</Text>
  <CheckBox
    value={includeNumber}
    onValueChange={setIncludeNumber}
    tintColors={{ true: "#4CAF50", false: "#fff" }}
  />
</View>

<View style={styles.option}>
  <Text style={{ color: "#fff" }}>Include special symbols</Text>
  <CheckBox
    value={includeSymbol}
    onValueChange={setIncludeSymbol}
    tintColors={{ true: "#4CAF50", false: "#fff" }}
  />
</View>


      <Button title="GENERATE PASSWORD" onPress={generatePassword} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1c1b3a",
    padding: 20,
    justifyContent: "center",
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "white",
    textAlign: "center",
    marginBottom: 20,
  },
  outputBox: {
    backgroundColor: "#0f1230",
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  passwordText: {
    color: "white",
    fontSize: 16,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    justifyContent: "space-between",
  },
  input: {
    width: 80,
    borderWidth: 1,
    borderColor: "#aaa",
    borderRadius: 6,
    padding: 8,
    backgroundColor: "white",
    textAlign: "center",
  },
  option: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
});
